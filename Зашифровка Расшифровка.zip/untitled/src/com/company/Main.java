package com.company;


import com.sun.jdi.connect.spi.TransportService;

import javax.net.ssl.KeyStoreBuilderParameters;
import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.io.*;
import java.lang.reflect.Array;
import java.net.ServerSocket;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.text.CollationElementIterator;
import java.util.*;

public class Main {
                                     //Зашифровщик/Расшифровщик

    static JeSwing jeSwing = new JeSwing();

    public static void main(String[] args) throws IOException {

        jeSwing.runGui();

    }

    public static void encryptFileName(File file) throws IOException {
        System.out.println("Введите путь где будет создан зашифрованный файл");

        PrintStream printStream = new PrintStream(file.getAbsoluteFile()); // file.getAbsoluteFile() - показывает полное название файла(конечное).тоесть ты ввел путь к файлу, а он показал.

        System.out.println("Введите ваш текст");

        String printYourText = JeSwing.jTextArea.getText(); // тут сохраняется веденый текст из интерфейса jTextArea

        System.out.println("Зашифрованный файл создан по пути: " + file.getAbsoluteFile());
        char[] ch = printYourText.toCharArray(); // сохраненый текст разбивается на чар
        String result = ""; // сюда записывается все символы из чара прибавлные на значание 20. Тем самым зашифровав данные.
        for (int i = 0; i < ch.length; i++) {
            ch[i] += 20;
            result += ch[i];
        }
        //System.out.println(result);
        printStream.print(result); // тут результат записыватся в файл
    }


    public static void decipherFileName(File file) throws IOException {
        System.out.println("Введите путь до зашифрованного файла");

        BufferedReader bufferedReader = new BufferedReader(new FileReader(file.getAbsoluteFile()));

        String readBufer = bufferedReader.readLine();

        PrintStream printStream1 = new PrintStream(file.getAbsoluteFile());
        char[] ch1 = readBufer.toCharArray(); // тут предыдуший зашифрованый файл разбивается на чар
        String result2 = ""; // сюда записывается символы из чара уменьшеные на 20. Тем сымым возвращая прежнее значение.
        for (int i = 0; i < ch1.length; i++) {
            ch1[i] -= 20;
            result2 += ch1[i];
        }
        //System.out.println(result2);
        printStream1.print(result2);// тут результат записыватся в файл
        System.out.println("Файл расшифрован. Находится по пупи" + file.getAbsoluteFile());
    }

}