package com.company;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

import javax.swing.*;
import javax.swing.text.JTextComponent;

public class JeSwing {

    public static JTextArea jTextArea = new JTextArea(); // Класа который записывает всебя текст из программы, тем самым передавая ее в файл.
    static JFrame jFrame = getFrame();
    static JPanel jPanel = new JPanel(); // Панелька на котором размещается кнопка
    //static JDialog jDialog = getJDialog();
    static MyDialog myDialog = new MyDialog();

    public void runGui() {
        JButton jButtonEncrypt = new JButton("Засшифровать");
        JButton jButtonDencrypt = new JButton("Расшифровать");

        jFrame.add(jPanel);
        jFrame.add(jPanel);
        jFrame.add(jPanel);

        jPanel.add(jButtonEncrypt);
        jPanel.add(jButtonDencrypt);

        jButtonEncrypt.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                myDialog.setVisible(true); //запускается метод при нажатии кнопки "Save"
            }
        });


        jButtonDencrypt.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                JFileChooser jfileChooser = new JFileChooser();
                jfileChooser.showOpenDialog(jPanel);
                int ret = jfileChooser.showDialog(null, "расшифровать файл");
                if (ret == JFileChooser.APPROVE_OPTION) {
                    File file = jfileChooser.getSelectedFile(); // jfileChooser.getSelectedFile()-хранит в себе путь к файлу в текставом ввиде, после чего передается в File.
                    System.out.println(file.getAbsoluteFile()); // тут увидешь явный пример
                    try {
                        Main.decipherFileName(file.getAbsoluteFile()); // берется медот расшифровки из основного класса Main и передает в аргумент полный путь к файлу хранящая в String
                    } catch (IOException ex) {
                        ex.printStackTrace();
                    }
                }
            }
        });

    }


    public static JFrame getFrame() {
        JFrame frame = new JFrame();
        frame.setVisible(true);
        frame.setBounds(500, 250, 300, 80);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setName("fasf");
        return frame;

    }


    static class MyDialog extends JDialog {
        JButton jButton = new JButton("Save");

        public MyDialog() {

            super(jFrame, "Запишите текст");
            add(jTextArea, BorderLayout.NORTH);
            add(jButton, BorderLayout.SOUTH);
            setBounds(500, 500, 500, 300);

            jButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    myDialog.setVisible(false);
                    JFileChooser jfileChooser = new JFileChooser();
                    jfileChooser.showOpenDialog(jPanel);
                    int ret = jfileChooser.showDialog(null, "засшифровать файл");
                    if (ret == JFileChooser.APPROVE_OPTION) {
                        File file = jfileChooser.getSelectedFile();
                        try {
                            Main.encryptFileName(file.getAbsoluteFile());

                        } catch (IOException ex) {
                            ex.printStackTrace();
                        }
                    }

                }
            });

        }
    }
}


