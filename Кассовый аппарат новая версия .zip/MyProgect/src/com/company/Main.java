package com.company;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.text.CollationElementIterator;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.*;
import java.util.Scanner;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.stream.IntStream;

public class Main {
    static BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
    static ConnectSqlServer connectSqlServer = new ConnectSqlServer();
    static MethotsForTablePersonData personData = new MethotsForTablePersonData();
    static MethotsForTableWareHouse wareHouse = new MethotsForTableWareHouse();

    static Bread bread;
    static Sugar sugar;
    static Milk milk;
    static Eggs eggs;

    static int countEggs = 0;
    static int countBread = 0;
    static int countSugar = 0;
    static int countMilk = 0;
    static int countGeneralSum = 0;

    // Milk productNum - 498645879
    // Eggs productNum - 498645175
    // Bread productNum - 498646931
    // Sugar productNum - 498641571

    public static void main(String[] args) throws IOException, SQLException {
        connectSqlServer.setLocalHostName("localhost");// названиме хоста
        connectSqlServer.setPortNumber("3306");// порт
        connectSqlServer.setDataBaseName("market"); // выбор базы данных для работы
        connectSqlServer.setLogin("root"); // логин
        connectSqlServer.setPassword("root");// пороль
        connectSqlServer.setselectedTable("warehouse");// выброная таблицы с которой будем работать
        connectSqlServer.mySqlRun(); //запускает скл с указанными данными
        //connectSqlServer.createTable();
        //connectSqlServer.deleteSelectTable();


        //Методы людей
        //personData.writeInMySqlData();
        // personData.insertInto("Sadu","Ibragimov","Gruz", "12000");
        //personData.addArrayPeople();
        //personData.createTable("warehouse(id int auto_INCREMENT,productName varchar(20),quantityProduct int, priceProduct int ,dateManufactureProduct date,dateEndProduct date");
        //personData.dropTable();
        //personData.dropTable("har");
        //personData.deleteFromTableId(2);
        //personData.deleteAllDataFromTable();
        //personData.deleteFromTableBefore(17,23);
        //personData.sortIdAutoIncrement();
        //personData.updateDataInTable("id","4",12);
        //personData.deleteFromTableName("habaibula");
        //personData.deleteFromTableIN();
        //personData.updateDataInTable("surname","Shahbano",1);


        // Методы склада
        //wareHouse.insertInto("Сок", "20", "55", 498662039);
        //wareHouse.getFindByProductName("хлеб");
        System.out.println(wareHouse.getProductKod("хлеб"));
        System.out.println(wareHouse.getProductName("хлеб"));
        System.out.println(wareHouse.getProductPrice("хлеб"));
        System.out.println(wareHouse.getProductQuantity("хлеб"));
        System.out.println(wareHouse.getIsDigit(wareHouse.getProductPrice("хлеб")));
        wareHouse.updateDataTableById("productKod", "498693523", 5);
        //wareHouse.updateDataTableByName("quantity", "65", "Сок");
        //wareHouse.updateDataTableByProductKod("price", "20", 214121);
        //wareHouse.updateDataTableByProductKod();
        // wareHouse.deleteAllDataFromTable();
       // wareHouse.deleteFromTableBefore();
       // wareHouse.deleteFromTableId();
       // wareHouse.deleteFromTableIN(); Допиши делеты и проверь, есть ли еще не использованные методы
       // wareHouse.deleteFromTableName();
        // Сделай обзор на методы
        //wareHouse.getProducAlltData();
        System.out.println();
        // checkKod();

    }

    static void checkKod() throws IOException, SQLException {  // сканит штрих код
        System.out.println("Введите код продукта");
        bread = new Bread();
        milk = new Milk();
        sugar = new Sugar();
        eggs = new Eggs();

        String scanKod;
        while (true) {
            scanKod = bufferedReader.readLine();
            if (scanKod.equals("exit")) {
                System.exit(-1);
            } else if (scanKod.equals("paid")) {
                milk.productChangeQuantity(countMilk);
                bread.productChangeQuantity(countBread);
                eggs.productChangeQuantity(countEggs);
                sugar.productChangeQuantity(countSugar);

                System.out.println(" Ваш чек!" + "\n" + "Общая cумма: " + countGeneralSum + "p");
                System.out.println();
                System.out.println("Склад обновился");
                wareHouse.getProducAlltData();
                System.exit(0);
            }

            try {
                int numKod = Integer.parseInt(scanKod);
                switch (numKod) {
                    case (498645879): //Milk
                        countMilk++;
                        milk.getSmallInfoProduct();
                        countGeneralSum += Integer.parseInt(wareHouse.getIsDigit(milk.getPrice()));
                        break;

                    case (498645175): //Eggs
                        countEggs++;
                        eggs.getSmallInfoProduct();
                        countGeneralSum += Integer.parseInt(wareHouse.getIsDigit(eggs.getPrice()));
                        break;

                    case (498646931): //Bread
                        countBread++;
                        bread.getSmallInfoProduct();
                        countGeneralSum += Integer.parseInt(wareHouse.getIsDigit(bread.getPrice()));
                        break;

                    case (498641571): //Sugar
                        countSugar++;
                        sugar.getSmallInfoProduct();
                        countGeneralSum += Integer.parseInt(wareHouse.getIsDigit(sugar.getPrice()));
                        break;
                    default:
                        System.out.println("Такого продукта нету");
                }
            } catch (NumberFormatException e) {

            }
            System.out.println("Сумма: " + countGeneralSum + "p");
        }
    }


//    static void getCountWarehouse() { // выводит краткую информацию о складе
//        for (int i = 0; i < warehouse.size(); i++) {
//            if (warehouse.get(i).getClass().getName().contains(milk.getClass().getName())) {
//                countMilk++;
//            } else if (warehouse.get(i).getClass().getName().contains(eggs.getClass().getName())) {
//                countEggs++;
//            } else if (warehouse.get(i).getClass().getName().contains(bread.getClass().getName())) {
//                countBread++;
//            }
//
//        }
//        System.out.println("Склад.");
//        System.out.println(milk.getName() + " x " + countMilk);
//        System.out.println(eggs.getName() + " x " + countEggs);
//        System.out.println(bread.getName() + " x " + countBread);
//    }


//    static void getInfoWarehouse() { //выводит полную  информацию о складе
//        for (Object warehouseResult : warehouse) {
//            System.out.println(warehouseResult);
//        }
//    }
//
//    static void addProductToWarehouse() { // добавляет продукты в склад
//        warehouse.addAll(milkDepartment);
//        warehouse.addAll(eggsDepartment);
//        warehouse.addAll(breadDepartment);
//    }
//
//    static void addproducPackaging(GeneralProductClass generalProductClass) { // добавляет продукты упаковкай по 5 шт
//        for (int i = 0; i < 5; i++) {
//            warehouse.add(generalProductClass);
//        }
//    }


// придумай общий класс для всех обьектов;
}
