package com.company;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.CollationElementIterator;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.*;
import java.util.Scanner;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.stream.IntStream;

public class Main {

    static BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));

    static ArrayList<GeneralProductClass> warehouse = new ArrayList<>(); //склад
    static ArrayList<Milk> milkDepartment = new ArrayList<>(); // отдел молока
    static ArrayList<Eggs> eggsDepartment = new ArrayList<>(); // отдел Яиц
    static ArrayList<Bread> breadDepartment = new ArrayList<>(); // отдел Хлеба

    static int countMilk = 0;
    static int countBread = 0;
    static int countEggs = 0;
    static int generalSum = 0;

    static Milk milk = new Milk();
    static Eggs eggs = new Eggs();
    static Bread bread = new Bread();

    // Milk productNum - 498645879
    // Eggs productNum - 498645175
    // Bread productNum - 498646931

    public static void main(String[] args) throws IOException {

        milkDepartment.add(milk);
        milkDepartment.add(milk);
        eggsDepartment.add(eggs);
        breadDepartment.add(bread);

        // getCountWarehouse(); // узнай почему при нескольких вызовах метода, увеличиваются предметы на складе!

        addProductToWarehouse();
       // getCountWarehouse();
        checkKod();
        //addproducPackaging(milk);
         //getInfoWarehouse();
        System.out.println();

    }

    static void checkKod() throws IOException {  // сканит штрих код
        String scanKod;
        while (true) {
            scanKod = bufferedReader.readLine();
            if (scanKod.equals("exit")) {
                System.exit(-1);
            } else if (scanKod.equals("paid")) {
                System.out.println(" Ваш чек!" + "\n" + "Общая cумма:" + generalSum);
                getCountWarehouse();
                System.exit(0);
            }
            int numKod = Integer.parseInt(scanKod);
            if (numKod == 498645879) {
                System.out.println(milkDepartment.get(0));   // придумай как удалить обект после оплаты из склада
                generalSum += milk.getSumProduct();
                warehouse.remove(milkDepartment.get(0));

            } else if (numKod == 498645175) {
                System.out.println(eggsDepartment.get(0));
                generalSum += eggs.getSumProduct();
                warehouse.remove(eggsDepartment.get(0));
            } else if (numKod == 498646931) {
                System.out.println(breadDepartment.get(0));
                generalSum += bread.getSumProduct();
                warehouse.remove(breadDepartment.get(0));
            }
            System.out.println("Сумма: " + generalSum);
        }
    }


    static void getCountWarehouse() { // выводит краткую информацию о складе
        for (int i = 0; i < warehouse.size(); i++) {
            if (warehouse.get(i).getClass().getName().contains(milk.getClass().getName())) {
                countMilk++;
            } else if (warehouse.get(i).getClass().getName().contains(eggs.getClass().getName())) {
                countEggs++;
            } else if (warehouse.get(i).getClass().getName().contains(bread.getClass().getName())) {
                countBread++;
            }

        }
        System.out.println("Склад.");
        System.out.println(milk.getName() + " x " + countMilk);
        System.out.println(eggs.getName() + " x " + countEggs);
        System.out.println(bread.getName() + " x " + countBread);
    }


    static void getInfoWarehouse() { //выводит полную  информацию о складе
        for (Object warehouseResult : warehouse) {
            System.out.println(warehouseResult);
        }
    }

    static void addProductToWarehouse() { // добавляет продукты в склад
        warehouse.addAll(milkDepartment);
        warehouse.addAll(eggsDepartment);
        warehouse.addAll(breadDepartment);
    }

    static void addproducPackaging(GeneralProductClass generalProductClass) { // добавляет продукты упаковкай по 5 шт
        for (int i = 0; i < 5; i++) {
            warehouse.add(generalProductClass);
        }
    }


// придумай общий класс для всех обьектов;
}
