package com.company;

public class Eggs extends GeneralProductClass {
    private int numberProduct = 498645175;
    private String name = "Яица";
    private int sumProduct = 120;

    public Eggs() {

    }

    public Eggs(String name, int sumProduct) {
        super(name, sumProduct);
        this.sumProduct = sumProduct;
    }

    public String getName() {
        return name;
    }

    public int getSumProduct() {
        return sumProduct;
    }

    public void setSumProduct(int sumProduct) {
        this.sumProduct = sumProduct;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getNumberProduct() {
        return numberProduct;
    }

    public void setNumberProduct(int numberProduct) {
        this.numberProduct = numberProduct;
    }

    public String toString() {
        return "Штрих код-" +numberProduct + ". " +name + " " + sumProduct + "p";
    }



}

