package com.company;

public class GeneralProductClass extends GeneralProductFeatures {

    public GeneralProductClass() {

    }
    public GeneralProductClass(String name, int sumProduct) {
        super(name, sumProduct);
    }

}
