package com.company;

public class Milk extends GeneralProductClass {
    private final int numberProduct = 498645879;
    private String name = "Молоко";
    private int sumProduct = 75;
    private char sex = 'M';

    public Milk() {

    }

    public Milk(String name, int sumProduct, char sex) {
        super(name, sumProduct);
        this.sumProduct = sumProduct;
        this.sex = sex;
    }

    public Milk(String name, int sumProduct) {
        super(name, sumProduct);
        this.sumProduct = sumProduct;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public char isSex() {
        return sex;
    }

    public void setSex(char sex) {
        this.sex = sex;
    }

    public int getNumberProduct() {
        return numberProduct;
    }

    public int getSumProduct() {
        return sumProduct;
    }

    public void setSumProduct(int sumProduct) {
        this.sumProduct = sumProduct;
    }

    public char getSex() {
        return sex;
    }

    public String toString() {
        return "Штрих код-" +numberProduct + ". " +name + " " + sumProduct + "p," + " Пол:" + sex;
    }


}
