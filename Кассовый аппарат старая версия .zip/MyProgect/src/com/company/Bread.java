package com.company;

public class Bread extends GeneralProductClass {

    private int numberProduct = 498646931;
    private String name = "Хлеб";
    private int sumProduct = 30;


    public Bread() {

    }

    public int getSumProduct() {
        return sumProduct;
    }

    public void setSumProduct(int sumProduct) {
        this.sumProduct = sumProduct;
    }

    public Bread(String name, int sumProduct) {
        super(name, sumProduct);
        this.sumProduct = sumProduct;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getNumberProduct() {
        return numberProduct;
    }

    public void setNumberProduct(int numberProduct) {
        this.numberProduct = numberProduct;
    }

    public String toString() {
        return "Штрих код-" +numberProduct + ". " +name + " " + sumProduct + "p";
    }


}
