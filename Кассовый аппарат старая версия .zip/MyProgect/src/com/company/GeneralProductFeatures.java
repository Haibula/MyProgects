package com.company;

public abstract class GeneralProductFeatures {
    private String name;
    private int sumProduct;

    public GeneralProductFeatures(String name, int sumProduct) {
        this.name = name;
        this.sumProduct = sumProduct;
    }

    public GeneralProductFeatures() {

    }

    @Override
    public String toString() {
        return
                        ", name='" + name + '\'' +
                        ", sumProProduct=" + sumProduct +
                        '}';
    }

}
